package com.Team4.SmartTowns;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartTownsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartTownsApplication.class, args);
	}

}
