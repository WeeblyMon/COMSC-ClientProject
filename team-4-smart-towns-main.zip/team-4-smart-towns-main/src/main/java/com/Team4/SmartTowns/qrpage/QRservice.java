package com.Team4.SmartTowns.qrpage;

public class QRservice {

}
