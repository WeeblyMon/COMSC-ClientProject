package com.Team4.SmartTowns.testscripts;

public interface DefaultsGenerator {
    void generateTrailsAndUsers();
}
